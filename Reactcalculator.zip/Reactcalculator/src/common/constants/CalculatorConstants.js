'use strict';

import keyMirror from 'keymirror';

module.exports = keyMirror({
  KEY_TYPED: null,
  FORMULA_TYPED: null
});
